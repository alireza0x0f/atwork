#!/bin/bash

# Update the time so we are in sync
ntpdate 10.100.0.11