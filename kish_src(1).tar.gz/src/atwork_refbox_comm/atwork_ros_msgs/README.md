# ROS Message for RoboCup@Work RefBox

These messages are ROS translations of the official protobuf messages.
