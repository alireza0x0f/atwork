# protobuf_comm

This CMake project locates the protobuf_comm library from the atwork-refbox and builds it.
It is installed into your catkin workspace for ros packages to find and use.
